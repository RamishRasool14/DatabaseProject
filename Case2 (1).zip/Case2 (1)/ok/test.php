<?php
$result = array("red","green");
array_push($result, "blue");
echo $result;


?>
